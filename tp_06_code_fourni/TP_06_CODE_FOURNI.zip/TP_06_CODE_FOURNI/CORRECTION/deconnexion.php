<?php
    // note : il n'y a pas d'entête HTTP car le script se termine
    //        par une redirection vers une page qui a l'entête
?>
<?php
    // TODO 3.7 : il y a quelque chose à faire ici, en premier, pour la gestion de l'authentification
    session_start();

    include_once('auth.php');

    // TODO 3.7 :
    // - déconnecter l'internaute
    // - redirection vers la page d'accueil main.php
    if (isAuthenticate())
        unsetAuthenticate();
        
    header('Location: main.php');

