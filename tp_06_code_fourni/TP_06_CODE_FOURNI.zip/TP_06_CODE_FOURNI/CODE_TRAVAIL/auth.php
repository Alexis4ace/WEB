<?php
    // fonction indiquant que l'internaute courant est correctement authentifié
    function setAuthticate()
    {
        // TODO 3.7
    }

    // fonction indiquant que l'internaute courant n'est pas/plus correctement authentifié
    function unsetAuthenticate()
    {
        // TODO 3.7
    }

    // function indiquant si l'internaute courant est correctement authentifié
    function isAuthenticate()
    {
        return false;  // TODO 3.7 : remplacer par le code correct
    }

    // fonction redirigeant l'internaute vers la page main.php s'il n'est pas authentifié
    function exitIfNotAuthenticate()
    {
        // TODO 3.7
    }

