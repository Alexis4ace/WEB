<?php
    // initialisations et inclusions

    // TODO 3.7 : il y a quelque chose à faire ici, en premier, pour la gestion de l'authentification
    session_start();

    include_once('auth.php');
    include_once('bd.php');

    // TODO 3.7 : redirection vers la page d'accueil si l'internaute n'est pas authentifié
    exitIfNotAuthenticate();
    // TODO 3.3 : connexion au serveur de bases de données
    bd_connexion();
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <title>TP 6</title>
        <link rel="stylesheet" media="all" type="text/css" title="Mon Style" href="style.css" />
    </head>
    <body>
        <p>
            Retour à la <a href="main.php">page principale</a><br />
            <a href="deconnexion.php">Déconnexion</a>
        </p>

        <h1>exo 3.3, affichage des habitants</h1>

        <h2>Choix de la ville</h2>

        <form method="post" action="aff_habitants.php">
            <p>
                Quelle ville :
                <select name="ville">
                    <?php
                        $sql = 'SELECT * FROM tp_villes';
                        // TODO 3.3 :
                        // - faire la requête SQL
                        // - créer les éléments de la liste déroulante
                        // - penser à appeler closeCursor()
                        $result = bd_requete($sql, true);
                        while (($ligne = $result->fetch(PDO::FETCH_ASSOC)) !== false)
                            echo '<option value="' . $ligne['id']  .'">' . $ligne['nom'] .'</option>';
                        $result->closeCursor();
                    ?>
                </select>
                <input type="submit" value="go"/>
            </p>
        </form>


        <h2>Liste des habitants</h2>

        <?php
            // TODO 3.3 : s'il n'y a pas de formulaire
            if (empty($_POST))      // TODO 3.3 : à remplacer par le bon test
                echo '<p>Choisissez une ville</p>';
            else
            {
                $sql = 'SELECT tp_villes.nom FROM tp_villes WHERE tp_villes.id = :id';
                // TODO 3.3 : exécuter la requête préparée avec l'id reçue du formulaire
                $result = bd_requete_preparee($sql, ['id' => $_POST['ville']], true);
                // TODO 3.3 : s'il n'y a pas de résultat
                $ligne = $result->fetch(PDO::FETCH_ASSOC);
                if ($ligne === false)     // TODO 3.3 : à remplacer par le bon test
                {
                    // TODO 3.3 :  penser à appeler closeCursor()
                    $result->closeCursor();
                    echo '<p>Ville inconnue</p>';
                }
                else
                {
                    $villeNom = $ligne['nom'];
                    // TODO 3.3 : penser à appeler closeCursor()
                    $result->closeCursor();
                    $sql = 'SELECT tp_auteurs.nom FROM tp_auteurs WHERE tp_auteurs.id_ville = :id_ville';
                    // TODO 3.3 : exécuter la requête préparée avec l'id reçue du formulaire
                    $result = bd_requete_preparee($sql, ['id_ville' => $_POST['ville']], true);
                    echo '<p>Nombre d\'habitants (ne marche pas avec SQLite) : ' . $result->rowCount() . ' dans ' . $villeNom . '</p>';
                    echo '<ul>';
                    // TODO 3.3 : afficher les habitants dans des items <li></li>
                    while (($ligne = $result->fetch(PDO::FETCH_ASSOC)) !== false)
                        echo '   <li>' . $ligne['nom'] . '</li>';
                    echo '</ul>';
                    // TODO 3.3 : penser à appeler closeCursor()
                    $result->closeCursor();
                }
            }
        ?>

    </body>
</html>
<?php
    // TODO 3.3 : déconnexion du serveur de bases de données
    bd_deconnexion();
?>

